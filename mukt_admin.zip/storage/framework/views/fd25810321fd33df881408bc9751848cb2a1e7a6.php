<!--<?php echo e(dump($custdetails)); ?>-->




<?php $__env->startSection('content'); ?>


<div class="row">
 <div class="col-md-8 col-md-offset-2">
   <h1 class="alert alert-success" role="alert">Customer Details</h1>

   <table class="table table-striped">
   		<tbody>

         <tr><td align="center">
               <a href="<?php echo e(route('customers.show',$custdetails->id)); ?>"> <img src="<?php echo e(asset('images/'.$img)); ?>"></a>
         </td></tr>

   		<tr><td>
  <b>
  Customer ID: <?php echo e(strtoupper($genid)); ?>

  </b>
  </td></tr>
  <tr>
  <td>
   Customer Name: <?php echo e($custdetails->name); ?>


   		</td></tr>
   		<tr><td>
   	<?php echo e($custdetails->relation); ?>'s Name:<?php echo e($custdetails->gardian); ?>

   	</td></tr>
   	
   	<tr><td>
   	Gender:<?php echo e($custdetails->gender); ?>

   	</td></tr>

    <tr><td>
     Marital Status:<?php echo e($custdetails->marital_status); ?>

   </td></tr>
   
   
     

    
    <tr><td>
   Pan No:<?php echo e($custdetails->pan_no); ?>

   	</td></tr>
   <tr><td>
   Aadhar No:<?php echo e($custdetails->aadhar_no); ?>

   	</td></tr>

   <tr><td>
   	Identity Proof Submitted:<?php echo e($custdetails->idproof); ?>

   	</td></tr>
   	<tr><td>
   	Born On:<?php echo e($custdetails->dob); ?>

   	</td></tr>

   	<tr><td>
   	Address:<?php echo e($custdetails->address); ?>,
   	<?php echo e($custdetails->city); ?>,
      <?php echo e($custdetails->country); ?>

   	<?php echo e($custdetails->pin); ?>,
   	<?php echo e($custdetails->state); ?>.
      </td></tr>
      <tr><td>
   	Group_id:<?php echo e($custdetails->group_id); ?>.
   	</td></tr>
    <tr><td>
   	Contact No:<?php echo e($custdetails->phone_no); ?>

   	</td></tr>
   	<tr><td>
   	Proof of Address:<?php echo e($custdetails->addressproof); ?>

   	</td></tr>
   	<tr><td>
   	Annual Salary:<?php echo e($custdetails->salary); ?>

   	</td></tr>

   	<tr><td>
   	Occupation:<?php echo e($custdetails->occupation); ?>

   	</td></tr>
   	<tr><td>
   	Joined At:<?php echo e(date('jS M, Y', strtotime($custdetails->created_at))); ?>

   	</td></tr>
   <tr><td>
   	Registered By:<?php echo e($custdetails->registered_by); ?>

   	</td></tr>

    		</tbody>
   	</table>
<tr><td >
   	<a href="<?php echo e(url('home')); ?>" class="btn btn-primary">Home Page</a>

      <?php if($custdetails->loan_alloted): ?>
   	<a href="<?php echo e(route('premiums.show',$custdetails->id)); ?>" class="btn btn-primary">Premium Status</a>
      <?php endif; ?>

         
 
</td></tr>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>