<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
        <div class="container-fluid">

<div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">REPORT DOWNLOAD</h1>
                </div>


 </div>

			 <div class="row">
			<a href="<?php echo e(url('/download')); ?>" class="btn btn-default btn-lg">
					  <span class="glyphicon glyphicon-save" aria-hidden="true"></span> Download Customer Details
			</a>
			 
			 </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>