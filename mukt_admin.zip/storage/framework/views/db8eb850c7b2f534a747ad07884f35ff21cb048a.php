<?php $__env->startSection('stylesheet'); ?>

	
    <?php echo Html::style('css/select2.css'); ?>     

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="container-fluid">


	<?php echo Form::open(['route' => 'group.store','data-parsley-validate'=>'']); ?>


    <?php echo e(Form::label('groupmembers','Select Members:')); ?>


    <select class="form-control select2-multi" name="groupmembers[]" multiple="multiple">
    
       <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <option value=<?php echo e($member->id); ?>><b><?php echo e($member->name); ?></b>,<?php echo e($member->phone_no); ?></option>
          
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php echo e(Form::submit('Go Create!', ['class'=>'btn btn-primary form-spacing-top'])); ?>

    
             
    <?php echo e(Form::close()); ?>



	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	
  <?php echo Html::script('js/select2.js'); ?>

  		<script type="text/javascript">
		$(".select2-multi").select2();
		</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>