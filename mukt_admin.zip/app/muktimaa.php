<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class muktimaa extends Model
{
    //
}
